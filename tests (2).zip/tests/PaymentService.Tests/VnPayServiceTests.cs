using Microsoft.Extensions.Options;
using PaymentService.Helpers;
using PaymentService.Models;
using PaymentService.Options;
using PaymentService.Services;
using Xunit;

namespace PaymentService.Tests;

public class VnPayServiceTests
{
    // Dữ liệu giả; giá trị kỳ vọng được tính độc lập bằng script tham chiếu Python (hmac + hashlib).
    private const string Secret = "DEMOSECRETKEY0123456789ABCDEFGH";
    private const string ExpectedSignData =
        "vnp_Amount=15000000&vnp_Command=pay&vnp_CreateDate=20261103160800&vnp_CurrCode=VND" +
        "&vnp_ExpireDate=20261103162300&vnp_IpAddr=127.0.0.1&vnp_Locale=vn" +
        "&vnp_OrderInfo=Thanh+toan+don+hang+DH20261103001&vnp_OrderType=other" +
        "&vnp_ReturnUrl=https%3A%2F%2Flocalhost%3A7001%2FPayment%2FVnPayReturn" +
        "&vnp_TmnCode=DEMOTMN1&vnp_TxnRef=DH20261103001&vnp_Version=2.1.0";
    private const string ExpectedHash =
        "09b1a76af1f5ba2848d605c07f10b1227a1907079e9d0876f430f3ecb47ad13eff87af5f9c09eb951025dcd2882ce7475362876a0542180ec415b377fd114736";

    private static VnPayService Create(Action<VnPayOptions>? tweak = null)
    {
        var o = new VnPayOptions { TmnCode = "DEMOTMN1", HashSecret = Secret, ReturnUrl = "https://localhost:7001/Payment/VnPayReturn" };
        tweak?.Invoke(o);
        // 09:08:00 UTC = 16:08:00 GMT+7
        return new VnPayService(Microsoft.Extensions.Options.Options.Create(o), new FakeTime(new DateTimeOffset(2026, 11, 3, 9, 8, 0, TimeSpan.Zero)));
    }

    private static Order NewOrder(decimal amount = 150000m, OrderStatus s = OrderStatus.Pending) =>
        new() { Id = 1, OrderCode = "DH20261103001", TotalAmount = amount, Status = s };

    [Fact]
    public void CreatePaymentUrl_MatchesReferenceVector()
    {
        var url = Create().CreatePaymentUrl(NewOrder(), "127.0.0.1");
        Assert.Equal($"https://sandbox.vnpayment.vn/paymentv2/vpcpay.html?{ExpectedSignData}&vnp_SecureHash={ExpectedHash}", url);
    }

    [Fact]
    public void HmacSha512_MatchesReferenceVector() =>
        Assert.Equal(ExpectedHash, VnPayLibrary.HmacSha512(Secret, ExpectedSignData));

    [Theory]
    [InlineData(150000, "15000000")]
    [InlineData(5000, "500000")]
    [InlineData(999999999, "99999999900")]
    public void Amount_IsMultipliedBy100(decimal vnd, string expected) =>
        Assert.Equal(expected, VnPayService.ToVnPayAmount(vnd));

    [Fact]
    public void Amount_WithFraction_IsRejected() =>
        Assert.Throws<ArgumentException>(() => VnPayService.ToVnPayAmount(1000.5m));

    [Fact]
    public void Parameters_AreSortedAndEmptyOnesDropped()
    {
        var q = VnPayLibrary.BuildQueryString(new Dictionary<string, string?>
        { ["vnp_b"] = "2", ["vnp_a"] = "1", ["vnp_empty"] = "", ["vnp_null"] = null, ["vnp_C"] = "3" });
        Assert.Equal("vnp_C=3&vnp_a=1&vnp_b=2", q);   // Ordinal: chữ hoa đứng trước chữ thường
    }

    [Fact]
    public void SecureHash_IsNotPartOfSignedData()
    {
        var url = Create().CreatePaymentUrl(NewOrder(), "127.0.0.1");
        var signed = url[(url.IndexOf('?') + 1)..url.LastIndexOf("&vnp_SecureHash=", StringComparison.Ordinal)];
        Assert.DoesNotContain("vnp_SecureHash", signed);
    }

    [Fact]
    public void Url_CanBeVerifiedByVerifySignature()
    {
        var url = Create().CreatePaymentUrl(NewOrder(), "127.0.0.1");
        var parsed = System.Web.HttpUtility.ParseQueryString(new Uri(url).Query);
        var dict = parsed.AllKeys.ToDictionary(k => k!, k => (string?)parsed[k]);
        Assert.True(VnPayLibrary.VerifySignature(dict, Secret));
        dict["vnp_Amount"] = "1";                       // bị sửa -> chữ ký sai
        Assert.False(VnPayLibrary.VerifySignature(dict, Secret));
    }

    [Fact]
    public void Ipv6Loopback_IsNormalized() =>
        Assert.Contains("vnp_IpAddr=127.0.0.1", Create().CreatePaymentUrl(NewOrder(), "::1"));

    [Theory]
    [InlineData(0)]
    [InlineData(-1)]
    [InlineData(1_000_000_000)]
    public void InvalidAmount_Throws(decimal amount) =>
        Assert.Throws<ArgumentException>(() => Create().CreatePaymentUrl(NewOrder(amount), "127.0.0.1"));

    [Theory]
    [InlineData(OrderStatus.Paid)]
    [InlineData(OrderStatus.Failed)]
    public void NonPendingOrder_Throws(OrderStatus s) =>
        Assert.Throws<InvalidOperationException>(() => Create().CreatePaymentUrl(NewOrder(s: s), "127.0.0.1"));

    [Theory]
    [InlineData("")]
    [InlineData("DH 001")]
    [InlineData("DH&001")]
    public void InvalidOrderCode_Throws(string code)
    {
        var o = NewOrder(); o.OrderCode = code;
        Assert.Throws<ArgumentException>(() => Create().CreatePaymentUrl(o, "127.0.0.1"));
    }

    [Fact]
    public void MissingSecret_FailsFast() =>
        Assert.Throws<InvalidOperationException>(() => Create(o => o.HashSecret = ""));

    [Fact]
    public void ExpireMinutesZero_OmitsExpireDate() =>
        Assert.DoesNotContain("vnp_ExpireDate", Create(o => o.ExpireMinutes = 0).CreatePaymentUrl(NewOrder(), "127.0.0.1"));
}
