namespace PaymentService.Tests;

internal sealed class FakeTime(DateTimeOffset utcNow) : TimeProvider
{
    public override DateTimeOffset GetUtcNow() => utcNow;
}
