using System.Net;
using System.Security.Cryptography;
using System.Text;

namespace PaymentService.Helpers;

/// <summary>
/// Hàm thuần (không phụ thuộc DB/HTTP) để dựng chuỗi dữ liệu và ký theo tài liệu VNPAY phiên bản 2.1.0.
/// Quy trình: (1) bỏ tham số rỗng, (2) sắp xếp tên tham số tăng dần theo mã ký tự (Ordinal),
/// (3) ghép "key=UrlEncode(value)" bằng "&", (4) HMAC-SHA512 với HashSecret, xuất hex chữ thường.
/// </summary>
public static class VnPayLibrary
{
    /// <summary>Tạo chuỗi dữ liệu cần ký / chuỗi query (hai chuỗi này PHẢI giống hệt nhau).</summary>
    public static string BuildQueryString(IDictionary<string, string?> parameters)
    {
        ArgumentNullException.ThrowIfNull(parameters);

        var sorted = new SortedDictionary<string, string>(StringComparer.Ordinal);
        foreach (var kv in parameters)
        {
            if (!string.IsNullOrEmpty(kv.Value))      // tham số rỗng không đưa vào chuỗi ký
                sorted[kv.Key] = kv.Value!;
        }

        var sb = new StringBuilder();
        foreach (var kv in sorted)
        {
            if (sb.Length > 0) sb.Append('&');
            sb.Append(WebUtility.UrlEncode(kv.Key)).Append('=').Append(WebUtility.UrlEncode(kv.Value));
        }
        return sb.ToString();
    }

    /// <summary>HMAC-SHA512(key = secret, data = signData), UTF-8, trả về hex chữ thường.</summary>
    public static string HmacSha512(string secret, string signData)
    {
        var key = Encoding.UTF8.GetBytes(secret);
        var data = Encoding.UTF8.GetBytes(signData);
        return Convert.ToHexStringLower(HMACSHA512.HashData(key, data));
    }

    /// <summary>
    /// Kiểm tra chữ ký của một bộ tham số trả về (dùng cho Return URL/IPN ở các mục sau).
    /// Loại vnp_SecureHash và vnp_SecureHashType khỏi dữ liệu trước khi băm lại.
    /// </summary>
    public static bool VerifySignature(IDictionary<string, string?> returned, string secret)
    {
        ArgumentNullException.ThrowIfNull(returned);
        if (!returned.TryGetValue("vnp_SecureHash", out var received) || string.IsNullOrEmpty(received))
            return false;

        var data = returned
            .Where(kv => kv.Key.StartsWith("vnp_", StringComparison.Ordinal)
                         && kv.Key != "vnp_SecureHash" && kv.Key != "vnp_SecureHashType")
            .ToDictionary(kv => kv.Key, kv => kv.Value);

        var expected = HmacSha512(secret, BuildQueryString(data!));
        return CryptographicOperations.FixedTimeEquals(
            Encoding.ASCII.GetBytes(expected),
            Encoding.ASCII.GetBytes(received.ToLowerInvariant()));
    }
}
