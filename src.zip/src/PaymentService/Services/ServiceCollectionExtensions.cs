using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using PaymentService.Options;

namespace PaymentService.Services;

public static class ServiceCollectionExtensions
{
    /// <summary>Đăng ký VnPayService + cấu hình. Gọi trong Program.cs: builder.Services.AddVnPay(builder.Configuration);</summary>
    public static IServiceCollection AddVnPay(this IServiceCollection services, IConfiguration configuration)
    {
        services.Configure<VnPayOptions>(configuration.GetSection(VnPayOptions.SectionName));
        services.AddSingleton<IVnPayService, VnPayService>();
        return services;
    }
}
