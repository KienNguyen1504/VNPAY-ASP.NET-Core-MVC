using System.Text.RegularExpressions;
using Microsoft.Extensions.Options;
using PaymentService.Helpers;
using PaymentService.Models;
using PaymentService.Options;

namespace PaymentService.Services;

public sealed partial class VnPayService : IVnPayService
{
    /// <summary>Hệ số quy đổi: VNPAY yêu cầu vnp_Amount = số tiền VND x 100 (bỏ phần thập phân).</summary>
    public const int AmountMultiplier = 100;

    /// <summary>Giới hạn trên của số tiền (VND) theo tài liệu: nhỏ hơn 1 tỷ đồng.</summary>
    public const decimal MaxAmountVnd = 999_999_999m;

    private static readonly TimeSpan VietnamOffset = TimeSpan.FromHours(7); // GMT+7

    private readonly VnPayOptions _options;
    private readonly TimeProvider _time;

    public VnPayService(IOptions<VnPayOptions> options, TimeProvider? timeProvider = null)
    {
        _options = options.Value;
        _options.EnsureValid();               // fail-fast nếu thiếu secret/cấu hình
        _time = timeProvider ?? TimeProvider.System;
    }

    public string CreatePaymentUrl(Order order, string? clientIpAddress)
    {
        ValidateOrder(order);

        var nowVn = _time.GetUtcNow().ToOffset(VietnamOffset);

        var p = new Dictionary<string, string?>
        {
            ["vnp_Version"]    = _options.Version,
            ["vnp_Command"]    = _options.Command,
            ["vnp_TmnCode"]    = _options.TmnCode,
            ["vnp_Amount"]     = ToVnPayAmount(order.TotalAmount),
            ["vnp_CreateDate"] = FormatVnTime(nowVn),
            ["vnp_CurrCode"]   = _options.CurrCode,
            ["vnp_IpAddr"]     = NormalizeIp(clientIpAddress),
            ["vnp_Locale"]     = _options.Locale,
            ["vnp_OrderInfo"]  = $"Thanh toan don hang {order.OrderCode}",   // tiếng Việt không dấu
            ["vnp_OrderType"]  = _options.OrderType,
            ["vnp_ReturnUrl"]  = _options.ReturnUrl,
            ["vnp_TxnRef"]     = order.OrderCode                              // mã tham chiếu duy nhất
        };

        if (_options.ExpireMinutes > 0)
            p["vnp_ExpireDate"] = FormatVnTime(nowVn.AddMinutes(_options.ExpireMinutes));

        var query = VnPayLibrary.BuildQueryString(p);                 // vừa là chuỗi ký vừa là query
        var secureHash = VnPayLibrary.HmacSha512(_options.HashSecret, query);

        // vnp_SecureHash được nối SAU khi ký và không nằm trong dữ liệu ký.
        return $"{_options.BaseUrl}?{query}&vnp_SecureHash={secureHash}";
    }

    /// <summary>Quy đổi VND -> đơn vị VNPAY (x100), chuỗi số nguyên, không dấu phân cách.</summary>
    public static string ToVnPayAmount(decimal amountVnd)
    {
        if (amountVnd != decimal.Truncate(amountVnd))
            throw new ArgumentException("Số tiền VND phải là số nguyên (không có phần lẻ).", nameof(amountVnd));
        return ((long)amountVnd * AmountMultiplier).ToString(System.Globalization.CultureInfo.InvariantCulture);
    }

    /// <summary>Định dạng yyyyMMddHHmmss theo múi giờ GMT+7.</summary>
    public static string FormatVnTime(DateTimeOffset vnTime) =>
        vnTime.ToString("yyyyMMddHHmmss", System.Globalization.CultureInfo.InvariantCulture);

    private static string NormalizeIp(string? ip)
    {
        if (string.IsNullOrWhiteSpace(ip) || ip == "::1") return "127.0.0.1";
        return ip.Trim();
    }

    private static void ValidateOrder(Order order)
    {
        ArgumentNullException.ThrowIfNull(order);

        if (string.IsNullOrWhiteSpace(order.OrderCode) || order.OrderCode.Length > 100 ||
            !OrderCodeRegex().IsMatch(order.OrderCode))
            throw new ArgumentException(
                "OrderCode không hợp lệ (bắt buộc, tối đa 100 ký tự, chỉ gồm chữ/số/-/_).", nameof(order));

        if (order.TotalAmount <= 0 || order.TotalAmount > MaxAmountVnd)
            throw new ArgumentException(
                $"TotalAmount phải lớn hơn 0 và không vượt quá {MaxAmountVnd:N0} VND.", nameof(order));

        if (order.Status != OrderStatus.Pending)
            throw new InvalidOperationException(
                $"Chỉ tạo URL thanh toán cho đơn ở trạng thái Pending (hiện tại: {order.Status}).");
    }

    [GeneratedRegex("^[A-Za-z0-9_-]+$")]
    private static partial Regex OrderCodeRegex();
}
