using PaymentService.Models;

namespace PaymentService.Services;

public interface IVnPayService
{
    /// <summary>
    /// Tạo URL thanh toán VNPAY cho một Order ĐÃ TỒN TẠI trong DB (Status = Pending).
    /// </summary>
    /// <param name="order">Order đọc từ DB (không dựng từ dữ liệu trình duyệt).</param>
    /// <param name="clientIpAddress">IP khách hàng (HttpContext.Connection.RemoteIpAddress).</param>
    string CreatePaymentUrl(Order order, string? clientIpAddress);
}
