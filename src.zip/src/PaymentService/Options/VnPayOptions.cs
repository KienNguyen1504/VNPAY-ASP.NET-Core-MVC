namespace PaymentService.Options;

/// <summary>
/// Cấu hình VNPAY, bind từ section "VnPay".
/// TmnCode và HashSecret KHÔNG được ghi trong appsettings.json hoặc commit lên Git:
/// nhập bằng User Secrets (dotnet user-secrets) hoặc biến môi trường VnPay__TmnCode, VnPay__HashSecret.
/// </summary>
public class VnPayOptions
{
    public const string SectionName = "VnPay";

    /// <summary>URL cổng thanh toán (Sandbox).</summary>
    public string BaseUrl { get; set; } = "https://sandbox.vnpayment.vn/paymentv2/vpcpay.html";

    /// <summary>Mã website (vnp_TmnCode) do VNPAY cấp. SECRET-LIKE: không commit.</summary>
    public string TmnCode { get; set; } = string.Empty;

    /// <summary>Chuỗi bí mật tạo chữ ký (vnp_HashSecret). SECRET: không commit, không log.</summary>
    public string HashSecret { get; set; } = string.Empty;

    /// <summary>URL VNPAY redirect người dùng về sau khi thanh toán (vnp_ReturnUrl).</summary>
    public string ReturnUrl { get; set; } = string.Empty;

    public string Version { get; set; } = "2.1.0";
    public string Command { get; set; } = "pay";
    public string CurrCode { get; set; } = "VND";

    /// <summary>"vn" hoặc "en".</summary>
    public string Locale { get; set; } = "vn";

    /// <summary>Mã danh mục hàng hóa (vnp_OrderType), ví dụ "other", "billpayment".</summary>
    public string OrderType { get; set; } = "other";

    /// <summary>Số phút giao dịch còn hiệu lực (vnp_ExpireDate = CreateDate + số phút này). 0 = không gửi.</summary>
    public int ExpireMinutes { get; set; } = 15;

    /// <summary>Ném lỗi sớm nếu thiếu cấu hình bắt buộc (không bao giờ in giá trị secret ra thông báo lỗi).</summary>
    public void EnsureValid()
    {
        var missing = new List<string>();
        if (string.IsNullOrWhiteSpace(BaseUrl)) missing.Add(nameof(BaseUrl));
        if (string.IsNullOrWhiteSpace(TmnCode)) missing.Add(nameof(TmnCode));
        if (string.IsNullOrWhiteSpace(HashSecret)) missing.Add(nameof(HashSecret));
        if (string.IsNullOrWhiteSpace(ReturnUrl)) missing.Add(nameof(ReturnUrl));
        if (missing.Count > 0)
            throw new InvalidOperationException(
                "Thiếu cấu hình VNPAY: " + string.Join(", ", missing) +
                ". Hãy nhập bằng User Secrets hoặc biến môi trường (section 'VnPay').");
        if (ExpireMinutes < 0)
            throw new InvalidOperationException("ExpireMinutes không được âm.");
    }
}
