namespace PaymentService.Models;

/// <summary>
/// Trạng thái nghiệp vụ của đơn hàng.
/// LƯU Ý: bản này chỉ là bản rút gọn để service chạy độc lập.
/// Khi ghép vào repo chung, XÓA file này và dùng enum/class do Phương, Tuệ đã chốt trong thư mục Models.
/// </summary>
public enum OrderStatus
{
    Pending = 0,
    Paid = 1,
    Failed = 2
}
