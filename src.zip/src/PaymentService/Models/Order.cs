namespace PaymentService.Models;

/// <summary>
/// Bản rút gọn của entity Order (chỉ gồm các trường VnPayService cần đọc).
/// Khi ghép vào repo chung, dùng class Order thật (Phương) và chỉ cần bảo đảm có
/// 3 thuộc tính: OrderCode, TotalAmount, Status (đổi tên cho khớp nếu khác).
/// </summary>
public class Order
{
    public int Id { get; set; }

    /// <summary>Mã đơn duy nhất do backend sinh; sẽ là vnp_TxnRef.</summary>
    public string OrderCode { get; set; } = string.Empty;

    /// <summary>Tổng tiền (VND) do backend tính từ DB, không nhận từ trình duyệt.</summary>
    public decimal TotalAmount { get; set; }

    public OrderStatus Status { get; set; } = OrderStatus.Pending;

    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
}
