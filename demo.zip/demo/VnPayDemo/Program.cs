using System.Text.RegularExpressions;
using Microsoft.Extensions.Options;
using PaymentService.Models;
using PaymentService.Options;
using PaymentService.Services;

// Demo chạy độc lập: dùng DỮ LIỆU GIẢ, in URL đã che thông tin.
// Khi chạy thật: lấy TmnCode/HashSecret từ User Secrets và KHÔNG in URL thật ra màn hình/báo cáo.
var options = Options.Create(new VnPayOptions
{
    TmnCode = Environment.GetEnvironmentVariable("VnPay__TmnCode") ?? "DEMOTMN1",
    HashSecret = Environment.GetEnvironmentVariable("VnPay__HashSecret") ?? "DEMOSECRETKEY0123456789ABCDEFGH",
    ReturnUrl = "https://localhost:7001/Payment/VnPayReturn"
});

IVnPayService service = new VnPayService(options);

var order = new Order { Id = 1, OrderCode = "DH20261103001", TotalAmount = 150000m, Status = OrderStatus.Pending };
var url = service.CreatePaymentUrl(order, "127.0.0.1");

Console.WriteLine("URL đầy đủ (chỉ dùng trong demo cục bộ) đã được che:\n");
Console.WriteLine(Mask(url));

static string Mask(string url)
{
    url = Regex.Replace(url, "vnp_TmnCode=[^&]*", "vnp_TmnCode=********");
    return Regex.Replace(url, "vnp_SecureHash=([0-9a-f]{8})[0-9a-f]*", "vnp_SecureHash=$1...[da-che]");
}
