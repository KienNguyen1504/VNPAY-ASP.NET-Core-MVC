using Microsoft.EntityFrameworkCore;
using PaymentService.Models;
using PaymentService.Services;
using VnPayWebDemo.Data;

var builder = WebApplication.CreateBuilder(args);

builder.Services.AddControllersWithViews();
builder.Services.AddDbContext<ApplicationDbContext>(o => o.UseInMemoryDatabase("vnpay-demo"));
builder.Services.AddVnPay(builder.Configuration);   // đọc section "VnPay"; TmnCode/HashSecret từ User Secrets

var app = builder.Build();

// Dữ liệu mẫu cho demo: 2 đơn Pending (đơn thật trong DB, không hard-code trong View).
using (var scope = app.Services.CreateScope())
{
    var db = scope.ServiceProvider.GetRequiredService<ApplicationDbContext>();
    db.Orders.AddRange(
        new Order { OrderCode = "DH20261106001", TotalAmount = 150000m, Status = OrderStatus.Pending },
        new Order { OrderCode = "DH20261106002", TotalAmount = 299000m, Status = OrderStatus.Pending });
    db.SaveChanges();
}

app.UseHttpsRedirection();
app.UseRouting();
app.UseAuthorization();
app.MapControllerRoute("default", "{controller=Orders}/{action=Index}/{id?}");
app.Run();
