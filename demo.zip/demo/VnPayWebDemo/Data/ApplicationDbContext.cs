using Microsoft.EntityFrameworkCore;
using PaymentService.Models;

namespace VnPayWebDemo.Data;

/// <summary>DbContext rút gọn cho demo (InMemory). Trong repo chung dùng ApplicationDbContext + LocalDB của nhóm.</summary>
public class ApplicationDbContext(DbContextOptions<ApplicationDbContext> options) : DbContext(options)
{
    public DbSet<Order> Orders => Set<Order>();

    protected override void OnModelCreating(ModelBuilder b)
    {
        b.Entity<Order>(e =>
        {
            e.Property(o => o.TotalAmount).HasPrecision(18, 0);
            e.HasIndex(o => o.OrderCode).IsUnique();
        });
    }
}
