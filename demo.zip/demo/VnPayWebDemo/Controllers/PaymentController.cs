using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using PaymentService.Models;
using PaymentService.Services;
using VnPayWebDemo.Data;

namespace VnPayWebDemo.Controllers;

/// <summary>
/// Mục 8, Chương 3: nút "Thanh toán qua VNPAY" -> VnPayService -> redirect sang Sandbox.
/// Quy tắc: số tiền và mã đơn chỉ lấy từ Order đọc từ DB; trình duyệt chỉ gửi orderId.
/// </summary>
[AutoValidateAntiforgeryToken]
public class PaymentController(
    ApplicationDbContext db,
    IVnPayService vnPay,
    ILogger<PaymentController> logger) : Controller
{
    [HttpPost]
    public async Task<IActionResult> Pay(int orderId)
    {
        // 1. Order thật từ DB
        var order = await db.Orders.AsNoTracking().FirstOrDefaultAsync(o => o.Id == orderId);
        if (order is null) return NotFound();

        // 2. Chỉ đơn Pending mới được thanh toán
        if (order.Status != OrderStatus.Pending)
        {
            TempData["Error"] = $"Đơn {order.OrderCode} không ở trạng thái chờ thanh toán.";
            return RedirectToAction("Details", "Orders", new { id = orderId });
        }

        // 3. Tạo URL bằng VnPayService
        string url;
        try
        {
            var ip = HttpContext.Connection.RemoteIpAddress?.ToString();
            url = vnPay.CreatePaymentUrl(order, ip);
        }
        catch (Exception ex) when (ex is ArgumentException or InvalidOperationException)
        {
            // Chỉ log mã đơn và lý do; KHÔNG log URL (chứa TmnCode, chữ ký) hay secret.
            logger.LogWarning("Không tạo được URL VNPAY cho đơn {OrderCode}: {Reason}", order.OrderCode, ex.Message);
            TempData["Error"] = "Không thể tạo yêu cầu thanh toán. Vui lòng thử lại hoặc liên hệ quản trị.";
            return RedirectToAction("Details", "Orders", new { id = orderId });
        }

        logger.LogInformation("Chuyển hướng thanh toán VNPAY cho đơn {OrderCode}", order.OrderCode);

        // 4. Redirect (HTTP 302) sang cổng Sandbox
        return Redirect(url);
    }

    /// <summary>
    /// TẠM THỜI (stub) để Sandbox có nơi quay về khi chạy demo. Chưa xác minh chữ ký, chưa đổi trạng thái đơn.
    /// Logic thật (verify chữ ký, đối chiếu Order, Pending/Success/Failed) thuộc mục 9 (Tuệ).
    /// </summary>
    [HttpGet]
    public IActionResult VnPayReturn() => View();
}
