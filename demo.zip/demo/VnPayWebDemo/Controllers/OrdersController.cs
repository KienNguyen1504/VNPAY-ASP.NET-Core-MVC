using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using VnPayWebDemo.Data;

namespace VnPayWebDemo.Controllers;

/// <summary>Trang danh sách và chi tiết đơn (bản rút gọn của mục 5, Chương 3). Chỉ để chứa nút Thanh toán.</summary>
public class OrdersController(ApplicationDbContext db) : Controller
{
    public async Task<IActionResult> Index() =>
        View(await db.Orders.AsNoTracking().OrderBy(o => o.Id).ToListAsync());

    public async Task<IActionResult> Details(int id)
    {
        var order = await db.Orders.AsNoTracking().FirstOrDefaultAsync(o => o.Id == id);
        return order is null ? NotFound() : View(order);
    }
}
